@echo off
chcp 65001 >nul
::������ԱȨ�ޣ���Ȩ���Զ�����UAC
fltmc >nul 2>&1 || (
    PowerShell -Command "Start-Process cmd -ArgumentList '/c ""%~f0""' -Verb RunAs"
    exit
)
cd /d "%~dp0"

echo ==============================================
echo                                            To win11
echo ==============================================
reg delete "HKCU\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}" /f
echo Restarting Windows Explorer......
taskkill /f /im explorer.exe
timeout /t 1 /nobreak >nul
start explorer.exe
echo.
echo success
pause
exit